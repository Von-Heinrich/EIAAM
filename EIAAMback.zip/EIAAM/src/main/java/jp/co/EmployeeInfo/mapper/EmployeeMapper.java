package jp.co.EmployeeInfo.mapper;

import jp.co.EmployeeInfo.model.EmployeeModel;
import jp.co.EmployeeInfo.pojo.EmployeePojo;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

	
@Mapper
public interface EmployeeMapper {
	
	  @Select("SELECT * FROM employee WHERE employeeNo = #{employeeNo}") 
	  EmployeeModel getEmployeeByNo(String employeeNo);
	  
	  //ログイン画面
		/*
		 * @Select("SELECT * FROM employee WHERE employeeNo = #{employeeNo} and password = #{password}"
		 * ) Employee getUser(String employeeNo, String password);
		 */
	  //@Select("SELECT * FROM employee WHERE employeeNo = #{employeeNo} and password = #{password}")
	  //EmployeePojo getUser(@Param("employeeName") String employeeName,@Param("password") String password);
	  
	  
	  @Select("SELECT * FROM employee WHERE employeeNo = #{employeeNo} and password = #{password}")
	  EmployeePojo getUser(@Param("employeeNo") String employeeNo,@Param("password") String password);
	  
	  
	  //authorityPropertiesを検索
	  @Select("SELECT authorityProperties FROM authority_master JOIN employee ON authority_master.authorityNo = employee.authorityCode WHERE employeeNo = #{username} and password = #{password}")
	  EmployeeModel findByUsername(String username,String password );
	  
	  //@Update("UPDATE employee SET password = #{newPassword} ,updateTime = NOW() WHERE employeeNo = #{employeeNo}")
	  int passwordReset(@Param("employeeNo") String employeeNo,@Param("newPassword") String newPassword);
	  
	  @Select("SELECT authorityProperties FROM authority_master WHERE authorityNo = #{authorityCode}") 
	  String getauthorityProperties(int authorityCode);
	  
	  
	  @Select("SELECT CONCAT(LEFT(employeeNo, 3), LPAD(SUBSTRING(employeeNo, 4) + 1, LENGTH(employeeNo) - 3, '0') ) AS newEmployeeNo FROM employee ORDER BY employeeNo DESC LIMIT 1")
	  String getMaxEmployeeNO();
	  
	  @Select("SELECT bankBranchName FROM bank_branch_master WHERE bankCode = #{bankNo}")
	  String getBranchNameByBankCode(String bankNo);
	  
	  @Select("SELECT bankBranchNo FROM bank_branch_master WHERE bankBranchName = #{branchName}")
	  String getBranchNo(String branchName);
	  
	  
	  @Select("SELECT bankBranchNo FROM bank_branch_master WHERE bankCode = #{bankNo}")
	  String checkBranchNoByBankCode(String bankNo);
	  
	  @Select("SELECT bankBranchName FROM bank_branch_master WHERE bankBranchNo = #{branchNo}")
	  String getBranchName(String branchNo);
	  
	  @Insert("INSERT INTO employee (employeeNo, employeeName, password, authorityCode, updateTime, createTime) VALUES (#{employeeNo}, #{employeeName}, #{firstPwd}, #{authorityCode}, NOW(), NOW())")
	  int employeeInsert(String employeeNo, String employeeName, String firstPwd, int authorityCode);
	  
	  
	  
	  
}


