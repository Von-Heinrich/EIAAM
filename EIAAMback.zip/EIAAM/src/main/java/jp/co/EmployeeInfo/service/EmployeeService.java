package jp.co.EmployeeInfo.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.EmployeeInfo.controller.EmployeeController;
import jp.co.EmployeeInfo.mapper.EmployeeMapper;
import jp.co.EmployeeInfo.model.EmployeeModel;
import jp.co.EmployeeInfo.model.ManageAddUser;
import jp.co.EmployeeInfo.pojo.EmployeePojo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

public interface EmployeeService {
	static final Logger logger = LoggerFactory.getLogger(EmployeeController.class);

	EmployeeModel getEmployeeByNo(String employeeNo);

	int insertEmployee(ManageAddUser manageAddUser);

	String checkBranchNoByBankCode(String bankNo, String branchNo);

	String checkBranchNameByBankCode(String BankCode, String BranchName);

	int passwordReset(String employeeNo, String newPassword);

	String MaxEmployeeNo();

	boolean passwordReset(String employeeNo, String password, String newPassword);

	EmployeePojo login(String employeeName, String password);

	EmployeeModel login2(String employeeName);
}

@Service
class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeMapper employeeMapper;

	@Override
	public EmployeeModel getEmployeeByNo(String employeeNo) {
		return employeeMapper.getEmployeeByNo(employeeNo);
	}

	// 権限


	@Override
	public EmployeePojo login(String employeeNo, String password) {
		logger.info("------service start-----");
		EmployeePojo employeePojo = employeeMapper.getUser(employeeNo,password);
		
		if(employeePojo !=null) {
			int authority =  employeePojo.getAuthorityCode();
			String getAuthorityPropertie = employeeMapper.getauthorityProperties(authority) ;
			
			
			employeePojo.setAuthorityProperties(getAuthorityPropertie);
			return employeePojo;
		}else {
			return null;
		}
			
			
		//	String getAuthorityProperties = employeeMapper.getauthorityProperties(authority);
			
			//logger.info("service getAuthorityProperties-----", getAuthorityProperties);
			
			
			
	}

	
	@Override
	public int passwordReset(String employeeNo, String newPassword) {
		
	  int employeeResult = employeeMapper.passwordReset(employeeNo, newPassword);
	  if(employeeResult == 1) {   logger.info("service true employeeResult-----", employeeResult);
		  
	  return employeeResult; 
	  }else {  logger.info("service false employeeResult-----", employeeResult);
		  
	  return 0;
		 }
	}

	@Override
	public EmployeeModel login2(String employeeNo) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String MaxEmployeeNo () {
		
		String EmployeeMaxNo = employeeMapper.getMaxEmployeeNO();
		
		if(EmployeeMaxNo != null) {
			
			return EmployeeMaxNo;
		}else {
		return null;
		}
		
	}

	@Override
	public boolean passwordReset(String employeeNo, String password, String newPassword) {
		// TODO Auto-generated method stub
		return false;
	}
	
	
	//銀行Codeで、入力した支店名の存在を確認する、ない場合、error；ある場合：支店番号を検索、フロントに反映
	@Override
	public String checkBranchNameByBankCode(String bankNo, String branchName) {
		
		//DBからの支店名をチェック
		String getBranchName = employeeMapper.getBranchNameByBankCode(bankNo);
		logger.info("------service getBranchName------", getBranchName);		
		
		if( getBranchName.equals(branchName)) {
			
			String branchNo = employeeMapper.getBranchNo(branchName);
			logger.info("------service branchNo------", branchNo);		
			
			if( branchNo != "") {
				return branchNo;
				
			}else {
				return "";
			}		
		}
		return null ;
		
	}
	
	//銀行Codeで、入力した支店番号の存在を確認する、ない場合、error；ある場合：支店名を検索、フロントに反映
	@Override
	public String checkBranchNoByBankCode(String bankNo, String branchNo) {
		
		//DBからの支店番号をチェック
		String checkedBranchNo = employeeMapper.checkBranchNoByBankCode(bankNo);
		logger.info("------service checkedBranchNo------", checkedBranchNo);		
		
		if( branchNo.equals(checkedBranchNo)) {
			
			String branchName = employeeMapper.getBranchName(branchNo);
			logger.info("------service branchName------", branchName);		
			
			if( branchName != "") {
				return branchName;
				
			}else {
				return "";
			}		
		}
		return null ;
	}
	
	
	//employee表にuserを追加
		@Override
		public int insertEmployee(ManageAddUser manageAddUser) {
			
		int insertResult = employeeMapper.employeeInsert(manageAddUser.getEmployeeNo(), manageAddUser.getEmployeeName(), manageAddUser.getFirstPwd(), manageAddUser.getAuthorityCode());
		
		logger.info("------service insertResult------", insertResult);			
		
			if( insertResult == 1) {
				return insertResult;	
			}else {
				return 0;
			}		
		}
	
	
		
		
		
		
		
	

}
