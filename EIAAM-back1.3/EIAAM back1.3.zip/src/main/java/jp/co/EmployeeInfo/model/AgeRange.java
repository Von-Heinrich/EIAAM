package jp.co.EmployeeInfo.model;

public class AgeRange {
	private int LAge;
    private int UAge;
	public int getLAge() {
		return LAge;
	}
	public void setLAge(int lAge) {
		LAge = lAge;
	}
	public int getUAge() {
		return UAge;
	}
	public void setUAge(int uAge) {
		UAge = uAge;
	}
    

}
